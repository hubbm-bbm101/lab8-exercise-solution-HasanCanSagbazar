import sys

students_file = open(sys.argv[1], "r+")
students_info = {names.split(":")[0]: str(names.split(":")[1]).replace("\n", "") for names in students_file}
name_list = sys.argv[2].split(",")

for name in name_list:
    try:
        print(f"Name : {name}, University : {students_info[name]}")

    except KeyError:
        print(f"No record of '{name}' was found")









